 clc
 clear all;
 close all;
warning('off');
sf    =   4;
addpath(genpath('data\'));
addpath(genpath('Comparison method\'));
for data_num=2
clear img
switch data_num    
    case 2
         load 'WDC.mat'
         img=WDC(1:256,1:256,1:93);
         name='DCmall';
end  
img=double(img);
O_Img = img/max(img(:));
S= O_Img ;
[M,N,L]=size(S);
sz=[M N];
%%
load('.\data\R.mat');
F=R;
F=F(:,1:end-10);
for band = 1:size(F,1)
        div = sum(F(band,:));
        for i = 1:size(F,2)
            F(band,i) = F(band,i)/div;
        end
end

%%
s0=1;
downsampling_scale = sf; 
psf        =    fspecial('gaussian',7,2);  %Gaussian sampling
par.fft_B      =    psf2otf(psf,sz);
par.B     =    ifft2(par.fft_B) ;
par.fft_BT     =    conj(par.fft_B);
par.H          =    @(z)H_z(z, par.fft_B, sf, sz,s0 );
par.HT         =    @(y)HT_y(y, par.fft_BT, sf, sz);
par.HTH         =    @(y)HTHx(y, par.fft_B, par.fft_BT,sf,sz,s0);
[M,N,L] = size(S);
S_bar = hyperConvert2D(S);
hyper= par.H(S_bar);
SNRh=30;
sigma = sqrt(sum(hyper(:).^2)/(10^(SNRh/10))/numel(hyper));
rng(10,'twister')
hyper = hyper+ sigma*randn(size(hyper));
HSI=hyperConvert3D(hyper,M/downsampling_scale, N/downsampling_scale );
rng(10,'twister')
Y = F*S_bar;
SNRm=35; 
sigmam = sqrt(sum(Y(:).^2)/(10^(SNRm/10))/numel(Y));
Y = Y+ sigmam*randn(size(Y));
MSI=hyperConvert3D(Y,M,N);
case1 = 'gauss';
case2 = num2str(SNRh);
case3 =  num2str(SNRm);

%%
Comparison_LLTNN = 1;

%% 10
if Comparison_LLTNN == 1;
 ex11='LLTNN';
addpath(genpath('LLTNN'));
addpath(genpath(cd));
aa = 0;
para.K=400;
para.eta=[3e-2, 1e-2, 2e-2]; 
para.p=10;
para.patchsize = 6;
t0=clock;
Z11 = Gernalized_LLTNN(HSI,MSI,F, par.fft_B,sf,S,para,aa);
t11=etime(clock,t0); 
rmpath(genpath('LLTNN'));
[psnr11,rmse11, ergas11, sam11, uiqi11,ssim11,DD11,CC11] = quality_assessment(double(im2uint8(S)), double(im2uint8(Z11)), 0, 1.0/sf);
disp(['PSNR_',ex11,'_',name ' = ',num2str(psnr11)]);
disp(['SSIM_',ex11,'_',name ' = ',num2str(ssim11)]);
disp(['ergas_',ex11,'_',name ' = ',num2str(ergas11)]);
disp(['sam_',ex11,'_',name ' = ',num2str(sam11)]);
disp(['uiqi_',ex11,'_',name ' = ',num2str(uiqi11)]);
disp(['DD_',ex11,'_',name ' = ',num2str(DD11)]);
disp(['CC_',ex11,'_',name ' = ',num2str(CC11)]);
end

end  