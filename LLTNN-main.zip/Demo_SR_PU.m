 clc
  clear all;
  close all;
warning('off');
sf    =   4;
addpath(genpath('data\'));
addpath(genpath('LLTNN\'));
load PU.mat
name= 'PU';
img=double(img);
O_Img = img/max(img(:));
S= O_Img ;
[M N L]=size(S);
sz=[M N];
%%
load('.\data\R.mat');
F=R;
F=F(:,1:end-10);
for band = 1:size(F,1)
        div = sum(F(band,:));
        for i = 1:size(F,2)
            F(band,i) = F(band,i)/div;
        end
end
%%
Comparison_LLTNN = 1;
%%
s0=1;
downsampling_scale = sf;
psf        =    fspecial('gaussian',7,2);
par.fft_B      =    psf2otf(psf,sz);
par.fft_BT     =    conj(par.fft_B);
par.H          =    @(z)H_z(z, par.fft_B, sf, sz,s0 );
par.HT         =    @(y)HT_y(y, par.fft_BT, sf, sz,s0);
[M,N,L] = size(S);
S_bar = hyperConvert2D(S);
hyper= par.H(S_bar);
SNRh=30;
sigma = sqrt(sum(hyper(:).^2)/(10^(SNRh/10))/numel(hyper));
rng(10,'twister')
hyper = hyper+ sigma*randn(size(hyper));
HSI=hyperConvert3D(hyper,M/downsampling_scale, N/downsampling_scale );
rng(10,'twister')
Y = F*S_bar;
SNRm=35;
sigmam = sqrt(sum(Y(:).^2)/(10^(SNRm/10))/numel(Y));
Y = Y+ sigmam*randn(size(Y));
MSI=hyperConvert3D(Y,M,N);
case1 = 'uni';
case2 = num2str(SNRh);
case3 =  num2str(SNRm);
%%
if Comparison_LLTNN == 1;
ex1='LLTNN';
cd 'LLTNN'
addpath(genpath(cd));
aa = 0;
para.K=400;
para.eta=[3e-2, 1e-2, 2e-2]; 
para.p=8;
para.patchsize = 6;
t0=clock;
Z1 =  Gernalized_LLTNN(HSI,MSI,F, par.fft_B,sf,S,para,aa);
t1=etime(clock,t0);    
cd ..
[psnr1,rmse1, ergas1, sam1, uiqi1,ssim1,DD1,CC1] = quality_assessment(double(im2uint8(S)), double(im2uint8(Z1)), 0, 1.0/sf);
disp(['PSNR_',ex1,'_',name ' = ',num2str(psnr1)]);
disp(['SSIM_',ex1,'_',name ' = ',num2str(ssim1)]);
disp(['ergas_',ex1,'_',name ' = ',num2str(ergas1)]);
disp(['sam_',ex1,'_',name ' = ',num2str(sam1)]);
disp(['uiqi_',ex1,'_',name ' = ',num2str(uiqi1)]);
disp(['DD_',ex1,'_',name ' = ',num2str(DD1)]);
disp(['CC_',ex1,'_',name ' = ',num2str(CC1)]);
end